﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Certification_Starting_Algor
{
    internal class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            try
            {
                //Pass the filepath and filename to the StreamWriter Constructor
                StreamWriter sw = new StreamWriter("C:\\Users\\Administrator\\source\\repos\\Certification_Starting_Algor\\Certification_Starting_Algor\\Test.txt");


                Stopwatch watch1 = new();
                int[] array1 = new int[] { 5, 2, 3 };
                Array.Sort(array1);
                watch1.Restart();
                var result1 = BinarySearch.BinarySearchIterative(array1, 5);
                //Write a line of text
                sw.WriteLine($"Execution Time: {watch1.Elapsed} ms.");
                sw.WriteLine($"The Index of array1 was: {result1}.\n");


                Stopwatch watch2 = new();
                int[] array2 = new int[] { 78, 55, 45, 98, 13 };
                watch2.Restart();
                BubbleSort.BubbleSortAlgorithm(array2, sw);
                sw.WriteLine($"\nExecution Time: {watch2.Elapsed} ms.\n");


                Stopwatch watch3 = new();
                int[] array3 = { 2, 3, 4, 10, 40 };
                int x = 10;
                watch3.Restart();

                // Function call
                int result = LinearSearch.search(array3, x);
                if (result == -1)
                {
                    sw.WriteLine("Element is not present in array");
                }

                else
                {
                    sw.WriteLine("Element is present at index "
                                        + result);
                    sw.WriteLine($"Execution Time: {watch2.Elapsed} ms.");
                }

                //Close the file
                sw.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);
            }
            finally
            {
                Console.WriteLine("Executing finally block.");
            }
            
        }
    }
}
